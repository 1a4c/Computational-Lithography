import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Initialize Gemini client on server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // API Route: Quantum Device Optimization & Physics Advisory via Gemini
  app.post("/api/optimize", async (req, res) => {
    try {
      const {
        gateLength,
        nanowireDiameter,
        oxideThickness,
        channelMaterial,
        sourceDoping,
        drainBias,
        gateBias,
        sdtLeakage,
        gateLeakage,
        thermionicCurrent,
        onOffRatio,
        ss,
        dibl,
        dslState
      } = req.body;

      const prompt = `
        You are an expert Device Physics Consultant specializing in Gate-All-Around (GAA) Transistor simulation, Quantum Tunneling analysis (Source-to-Drain Tunneling SDT, Direct and Fowler-Nordheim Gate Leakage), and sub-5nm node VLSI scaling.

        Analyze the following simulated GAA transistor state:
        - Channel Material: ${channelMaterial}
        - Gate Length (Lg): ${gateLength} nm (Direct Source-to-Drain Tunneling is critical below 5-7nm)
        - Nanowire/Nanosheet Diameter (D): ${nanowireDiameter} nm
        - Gate Oxide Thickness (Tox): ${oxideThickness} nm (Gate Leakage is critical below 1.2nm)
        - Source/Drain Doping: ${sourceDoping} cm^-3
        - Bias Conditions: Vd = ${drainBias} V, Vg = ${gateBias} V
        - Simulated Currents / Metrics:
          * Source-to-Drain Tunneling (SDT) Leakage: ${sdtLeakage} A
          * Gate Oxide Leakage: ${gateLeakage} A
          * Over-the-barrier (Thermionic) Current: ${thermionicCurrent} A
          * Ion/Ioff Ratio: ${onOffRatio}
          * Subthreshold Swing (SS): ${ss} mV/dec
          * DIBL: ${dibl} mV/V

        DSL Metaphor Configuration used:
        ${JSON.stringify(dslState)}

        Please provide:
        1. An in-depth, physics-driven analysis of the quantum tunneling effects (SDT and Gate Leakage) occurring in this specific GAA shell geometry.
        2. Structural and material recommendations (e.g., gate stack engineering, heterojunction channels, or channel thinness tuning) to optimize Ion/Ioff ratio and suppress tunneling.
        3. A customized optimized DSL command snippet that corresponds to the optimized sweep.
        4. Structured advice bullets.

        Return your response strictly in JSON format as specified in the response schema.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              analysis: {
                type: Type.STRING,
                description: "In-depth physics-driven quantum tunneling analysis in markdown format."
              },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    impact: { type: Type.STRING, description: "High, Medium, or Low" },
                    description: { type: Type.STRING }
                  },
                  required: ["title", "impact", "description"]
                },
                description: "List of structured recommendations."
              },
              optimalParameters: {
                type: Type.OBJECT,
                properties: {
                  gateLength: { type: Type.NUMBER, description: "Recommended Gate Length in nm" },
                  nanowireDiameter: { type: Type.NUMBER, description: "Recommended Nanowire/Nanosheet diameter in nm" },
                  oxideThickness: { type: Type.NUMBER, description: "Recommended Oxide Thickness in nm" },
                  channelMaterial: { type: Type.STRING, description: "Recommended optimal channel material" }
                },
                required: ["gateLength", "nanowireDiameter", "oxideThickness", "channelMaterial"]
              },
              dslOptimized: {
                type: Type.STRING,
                description: "An optimized version of the DSL statement tailored for this device state."
              }
            },
            required: ["analysis", "recommendations", "optimalParameters", "dslOptimized"]
          }
        }
      });

      const responseText = response.text || "{}";
      res.json(JSON.parse(responseText.trim()));
    } catch (error: any) {
      console.error("Gemini API optimization error:", error);
      res.status(500).json({ error: error.message || "Failed to generate optimization advice." });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
