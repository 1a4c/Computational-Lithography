import React, { useState, useMemo } from "react";
import { DeviceParams, DslState } from "./types";
import { runGaaSimulation } from "./lib/simulator";
import GaaVisualizer from "./components/GaaVisualizer";
import EnergyBandChart from "./components/EnergyBandChart";
import DslConsole from "./components/DslConsole";
import MetricsPanel from "./components/MetricsPanel";
import SweepPanel from "./components/SweepPanel";
import OptimizationAdvisor from "./components/OptimizationAdvisor";
import { Cpu, RotateCcw, Sliders, Zap, Shield, HelpCircle } from "lucide-react";

export default function App() {
  // 1. Initial State for Simulation Parameters
  const [params, setParams] = useState<DeviceParams>({
    gateLength: 6.0, // nm
    nanowireDiameter: 4.0, // nm
    oxideThickness: 1.2, // nm
    channelMaterial: "Si",
    sourceDoping: 1e20, // cm^-3
    drainBias: 0.6, // V
    gateBias: 0.0, // V (start in off state to view subthreshold tunneling)
    gateWorkFunction: 4.5, // eV
    temperature: 300 // K
  });

  // 2. Initial State for user's DSL configuration (maps user prompt keywords!)
  const [dsl, setDsl] = useState<DslState>({
    apiTriHeteo: true,
    uiGrid: "diverged",
    setPlantQueue: true,
    ecoAnchored: true,
    optimizationActive: true,
    trapAssistedTunneling: false,
    doubleChainSolver: false,
    monoFrequencyMatched: false,
    resonantEnergyLevel: 0.25
  });

  // 3. Run the live physical simulator whenever params or dsl changes
  const simulationResult = useMemo(() => {
    return runGaaSimulation(params, dsl);
  }, [params, dsl]);

  // Presets selector handler
  const loadPreset = (presetName: string) => {
    switch (presetName) {
      case "silicon-extreme":
        setParams({
          gateLength: 3.5,
          nanowireDiameter: 3.0,
          oxideThickness: 0.9,
          channelMaterial: "Si",
          sourceDoping: 1.2e20,
          drainBias: 0.7,
          gateBias: 0.0,
          gateWorkFunction: 4.6,
          temperature: 300
        });
        setDsl((prev) => ({ ...prev, apiTriHeteo: false, trapAssistedTunneling: false }));
        break;
      case "ingaas-mobility":
        setParams({
          gateLength: 8.0,
          nanowireDiameter: 5.0,
          oxideThickness: 1.4,
          channelMaterial: "InGaAs",
          sourceDoping: 8e19,
          drainBias: 0.5,
          gateBias: 0.5,
          gateWorkFunction: 4.4,
          temperature: 300
        });
        setDsl((prev) => ({ ...prev, apiTriHeteo: true }));
        break;
      case "mos2-2d":
        setParams({
          gateLength: 3.0,
          nanowireDiameter: 2.0,
          oxideThickness: 0.8,
          channelMaterial: "MoS2",
          sourceDoping: 1.5e20,
          drainBias: 0.8,
          gateBias: 0.0,
          gateWorkFunction: 4.8,
          temperature: 300
        });
        setDsl((prev) => ({ ...prev, apiTriHeteo: false }));
        break;
      case "oxide-leakage":
        setParams({
          gateLength: 10.0,
          nanowireDiameter: 6.0,
          oxideThickness: 0.6,
          channelMaterial: "Si",
          sourceDoping: 1e20,
          drainBias: 0.8,
          gateBias: 0.8,
          gateWorkFunction: 4.5,
          temperature: 320
        });
        setDsl((prev) => ({ ...prev, trapAssistedTunneling: true }));
        break;
      default:
        break;
    }
  };

  const handleReset = () => {
    setParams({
      gateLength: 6.0,
      nanowireDiameter: 4.0,
      oxideThickness: 1.2,
      channelMaterial: "Si",
      sourceDoping: 1e20,
      drainBias: 0.6,
      gateBias: 0.0,
      gateWorkFunction: 4.5,
      temperature: 300
    });
    setDsl({
      apiTriHeteo: true,
      uiGrid: "diverged",
      setPlantQueue: true,
      ecoAnchored: true,
      optimizationActive: true,
      trapAssistedTunneling: false,
      doubleChainSolver: false,
      monoFrequencyMatched: false,
      resonantEnergyLevel: 0.25
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans flex flex-col selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Header Bar */}
      <header className="h-14 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between px-6 shrink-0 z-50 sticky top-0 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-bold font-sans">G</div>
          <div>
            <h1 className="text-sm font-semibold tracking-tight uppercase text-slate-100">GAA Quantum Analysis Platform</h1>
            <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">GAA 殼層量子穿隧模擬平台 • Engine v4.2.0-LUM</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[10px] font-mono text-emerald-400">GPU SOLVER ACTIVE</span>
          </div>
          
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-4 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
            <span>重置引擎</span>
          </button>
        </div>
      </header>

      {/* Main Layout containing Sidebars and Center Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-visible">
        
        {/* Left Side: Analysis Modes & Workspace presets */}
        <aside className="w-full lg:w-64 border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-900/30 flex flex-col shrink-0 p-4 space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">
              Analysis Presets / 模擬預設模式
            </label>
            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => loadPreset("silicon-extreme")}
                className="w-full text-left px-3 py-2 hover:bg-slate-800/50 text-slate-300 hover:text-slate-100 rounded text-xs font-medium border border-transparent hover:border-slate-800/80 transition-all"
              >
                矽極限穿隧 (4nm)
              </button>
              <button
                onClick={() => loadPreset("ingaas-mobility")}
                className="w-full text-left px-3 py-2 hover:bg-slate-800/50 text-slate-300 hover:text-slate-100 rounded text-xs font-medium border border-transparent hover:border-slate-800/80 transition-all"
              >
                銦鎵砷高流速
              </button>
              <button
                onClick={() => loadPreset("mos2-2d")}
                className="w-full text-left px-3 py-2 hover:bg-slate-800/50 text-slate-300 hover:text-slate-100 rounded text-xs font-medium border border-transparent hover:border-slate-800/80 transition-all"
              >
                MoS₂ 2D 超微型
              </button>
              <button
                onClick={() => loadPreset("oxide-leakage")}
                className="w-full text-left px-3 py-2 hover:bg-slate-800/50 text-slate-300 hover:text-slate-100 rounded text-xs font-medium border border-transparent hover:border-slate-800/80 transition-all"
              >
                極薄氧化層崩潰
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">
              1. 通道半導體材料 (Channel Material)
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {(["Si", "Ge", "InGaAs", "MoS2"] as const).map((material) => (
                <button
                  key={material}
                  onClick={() => setParams((p) => ({ ...p, channelMaterial: material }))}
                  className={`text-xs py-1.5 px-2.5 rounded font-bold font-mono transition-all border ${
                    params.channelMaterial === material
                      ? "bg-indigo-600/10 text-indigo-400 border-indigo-500/40"
                      : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:border-slate-700"
                  }`}
                >
                  {material}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-auto">
            <div className="bg-indigo-950/20 border border-indigo-900/30 p-3 rounded">
              <p className="text-[9px] font-semibold text-indigo-300 uppercase tracking-wider">Current Workspace / 運作空間</p>
              <p className="text-xs text-indigo-100 truncate mt-1 font-mono">iRABBIT_Double_Chain_01</p>
              <p className="text-[9px] text-slate-500 mt-1">Self-consistent Poisson-Schrödinger</p>
            </div>
          </div>
        </aside>

        {/* Center Section: Core Visualizer and Energy Plots */}
        <main className="flex-1 flex flex-col p-6 gap-6 bg-slate-950 overflow-x-hidden">
          
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            
            {/* 3D Visualizer & Plots Area */}
            <div className="xl:col-span-8 space-y-6">
              {/* 3D Visualizer Section */}
              <GaaVisualizer params={params} dsl={dsl} />

              {/* Live Physical Charts */}
              <EnergyBandChart simulation={simulationResult} gateLength={params.gateLength} />
            </div>

            {/* Right Side: Parameter Sliders */}
            <div className="xl:col-span-4 bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md space-y-5">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                <Sliders className="text-indigo-400 w-4 h-4" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-widest">
                  Structure Parameters / 電晶體物性控制
                </h2>
              </div>

              {/* Sliders Block */}
              <div className="space-y-4">
                {/* Gate Length */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">閘極長度 Lg:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.gateLength} nm</span>
                  </div>
                  <input
                    type="range"
                    min="2.0"
                    max="15.0"
                    step="0.5"
                    value={params.gateLength}
                    onChange={(e) => setParams((p) => ({ ...p, gateLength: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>2nm (極限)</span>
                    <span>15nm</span>
                  </div>
                </div>

                {/* Nanowire Diameter */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">奈米線直徑 D:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.nanowireDiameter} nm</span>
                  </div>
                  <input
                    type="range"
                    min="2.0"
                    max="10.0"
                    step="0.5"
                    value={params.nanowireDiameter}
                    onChange={(e) => setParams((p) => ({ ...p, nanowireDiameter: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>2nm</span>
                    <span>10nm</span>
                  </div>
                </div>

                {/* Oxide Thickness */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">等效等效厚度 Tox:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.oxideThickness} nm</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="3.0"
                    step="0.1"
                    value={params.oxideThickness}
                    onChange={(e) => setParams((p) => ({ ...p, oxideThickness: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>0.5nm (穿隧臨界)</span>
                    <span>3.0nm</span>
                  </div>
                </div>

                {/* Gate Bias Vg */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">閘極偏壓 Vg:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.gateBias} V</span>
                  </div>
                  <input
                    type="range"
                    min="-0.2"
                    max="1.2"
                    step="0.05"
                    value={params.gateBias}
                    onChange={(e) => setParams((p) => ({ ...p, gateBias: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>-0.2V</span>
                    <span>1.2V</span>
                  </div>
                </div>

                {/* Drain Bias Vd */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">汲極偏壓 Vd:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.drainBias} V</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="1.2"
                    step="0.05"
                    value={params.drainBias}
                    onChange={(e) => setParams((p) => ({ ...p, drainBias: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>0.0V</span>
                    <span>1.2V</span>
                  </div>
                </div>

                {/* Gate Work Function */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">閘極功函數 WorkFunc:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.gateWorkFunction} eV</span>
                  </div>
                  <input
                    type="range"
                    min="4.0"
                    max="5.2"
                    step="0.05"
                    value={params.gateWorkFunction}
                    onChange={(e) => setParams((p) => ({ ...p, gateWorkFunction: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>4.0 eV</span>
                    <span>5.2 eV</span>
                  </div>
                </div>

                {/* Temperature */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-medium">工作溫度 Temperature:</span>
                    <span className="font-mono font-bold text-indigo-400">{params.temperature} K</span>
                  </div>
                  <input
                    type="range"
                    min="77"
                    max="450"
                    step="5"
                    value={params.temperature}
                    onChange={(e) => setParams((p) => ({ ...p, temperature: parseInt(e.target.value) }))}
                    className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                    <span>77 K (低溫)</span>
                    <span>450 K</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Bottom Grid for metrics, DSL consoles, optimization, and sweeping */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <MetricsPanel
              simulation={simulationResult}
              gateLength={params.gateLength}
              oxideThickness={params.oxideThickness}
            />
            <DslConsole dsl={dsl} setDsl={setDsl} />
          </div>

          {/* Sweep Panel (Only shown if set_plant_queue is active!) */}
          {dsl.setPlantQueue && (
            <SweepPanel params={params} dsl={dsl} />
          )}

          {/* AI advisor (Only shown if optimizationActive is enabled!) */}
          {dsl.optimizationActive && (
            <OptimizationAdvisor
              params={params}
              setParams={setParams}
              dsl={setDsl}
              sdtLeakage={simulationResult.sdtLeakage}
              gateLeakage={simulationResult.gateLeakage}
              thermionicCurrent={simulationResult.thermionicCurrent}
              ss={simulationResult.ss}
              dibl={simulationResult.dibl}
            />
          )}

        </main>
      </div>

      {/* Footer */}
      <footer className="h-10 border-t border-slate-800 bg-slate-900 flex items-center px-6 justify-between shrink-0 text-[10px] text-slate-500 font-mono">
        <div className="flex gap-4">
          <span>CRC: 0xF3A192</span>
          <span>SESSION ID: 8829-QX-04</span>
        </div>
        <div className="flex items-center gap-2">
          <span>GAA SIMULATION DECK ACTIVE</span>
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
        </div>
      </footer>
    </div>
  );
}
