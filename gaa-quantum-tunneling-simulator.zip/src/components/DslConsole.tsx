import React, { useState } from "react";
import { DslState } from "../types";
import { Cpu, Terminal, Play, CheckCircle, RefreshCw } from "lucide-react";

interface DslConsoleProps {
  dsl: DslState;
  setDsl: React.Dispatch<React.SetStateAction<DslState>>;
}

export default function DslConsole({ dsl, setDsl }: DslConsoleProps) {
  const [dslInput, setDslInput] = useState<string>(
    `api_tri_heteo(UI_uniform_diverged_boiled_slit().set_plant_queue[eco_anchored(vehicle_iMonkey.router_spray_lum.transform(lux_insuffice_event_sensitivity_slots.determined.attirbute(iRABBIT.Gi_routes_double_chain(),mono_frequency_matched(carrot_lum.transformed()))`
  );
  const [compiling, setCompiling] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  // Function to compile and map the DSL string to the actual React states
  const handleCompile = () => {
    setCompiling(true);
    setLogs(["[SYSTEM] GAA Compiler v1.25.0 initializing...", "[INFO] Fetching target DSL AST tree..."]);
    
    setTimeout(() => {
      setLogs((l) => [...l, "[OK] Found api_tri_heteo(): Enabling multi-gate heterostructure physics..."]);
    }, 400);

    setTimeout(() => {
      // Analyze current grid setting in the string
      let gridStyle: "uniform" | "diverged" | "boiled-slit" = "uniform";
      if (dslInput.includes("diverged")) {
        gridStyle = "diverged";
      } else if (dslInput.includes("boiled_slit")) {
        gridStyle = "boiled-slit";
      }
      
      setLogs((l) => [
        ...l,
        `[OK] Parsed UI_uniform_diverged_boiled_slit: Setting mesh strategy to [${gridStyle.toUpperCase()}]...`
      ]);

      // Set state based on whether keywords are in the string
      const updatedDsl: DslState = {
        apiTriHeteo: dslInput.includes("api_tri_heteo"),
        uiGrid: gridStyle,
        setPlantQueue: dslInput.includes("set_plant_queue"),
        ecoAnchored: dslInput.includes("eco_anchored"),
        optimizationActive: dslInput.includes("vehicle_iMonkey") || dslInput.includes("router_spray_lum"),
        trapAssistedTunneling: dslInput.includes("lux_insuffice_event_sensitivity_slots"),
        doubleChainSolver: dslInput.includes("iRABBIT") || dslInput.includes("double_chain"),
        monoFrequencyMatched: dslInput.includes("mono_frequency_matched"),
        resonantEnergyLevel: dsl.resonantEnergyLevel
      };

      setDsl(updatedDsl);
    }, 800);

    setTimeout(() => {
      setLogs((l) => [
        ...l,
        "[OK] Resolved eco_anchored boundary conditions. Schrödinger-Poisson solver prepared.",
        "[OK] Double-chain tight binding solver initialized successfully."
      ]);
    }, 1200);

    setTimeout(() => {
      setLogs((l) => [...l, "[SUCCESS] GAA Quantum DSL Compiled! All simulation attributes mapped."]);
      setCompiling(false);
    }, 1600);
  };

  const toggleParam = (key: keyof DslState, value: any) => {
    // Dynamically update the DSL string to match the toggled states
    // so the text area and the toggle switches stay in beautiful sync!
    setDsl((prev) => {
      const next = { ...prev, [key]: value };
      
      // Rebuild a formatted DSL string representing the active states
      let compiledStr = "";
      if (next.apiTriHeteo) {
        compiledStr += "api_tri_heteo(";
      } else {
        compiledStr += "api_standard_homo(";
      }

      compiledStr += `UI_${next.uiGrid === "boiled-slit" ? "boiled_slit" : next.uiGrid}().`;

      if (next.setPlantQueue) {
        compiledStr += "set_plant_queue[";
      }

      if (next.ecoAnchored) {
        compiledStr += "eco_anchored(";
      }

      if (next.optimizationActive) {
        compiledStr += "vehicle_iMonkey.router_spray_lum.transform(";
      }

      if (next.trapAssistedTunneling) {
        compiledStr += "lux_insuffice_event_sensitivity_slots.determined.attribute(";
      }

      if (next.doubleChainSolver) {
        compiledStr += "iRABBIT.Gi_routes_double_chain(),";
      }

      if (next.monoFrequencyMatched) {
        compiledStr += `mono_frequency_matched(carrot_lum.transformed())`;
      } else {
        compiledStr += "standard_broadband()";
      }

      // Close open brackets nicely
      if (next.trapAssistedTunneling) compiledStr += ")";
      if (next.optimizationActive) compiledStr += ")";
      if (next.ecoAnchored) compiledStr += ")";
      if (next.setPlantQueue) compiledStr += "]";
      compiledStr += ")";

      setDslInput(compiledStr);
      return next;
    });
  };

  return (
    <div id="dsl-console" className="bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Terminal className="text-indigo-400 w-5 h-5" />
          <div>
            <h3 className="text-sm font-semibold tracking-wide text-slate-200">
              GAA 量子編譯與 DSL 控制台
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Domain Specific Language Simulator Directives Compiler
            </p>
          </div>
        </div>
        <button
          onClick={handleCompile}
          disabled={compiling}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-slate-100 rounded text-xs font-mono font-bold transition-all"
        >
          {compiling ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span>編譯並套用 DSL</span>
        </button>
      </div>

      {/* DSL Syntax Editor */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Active DSL Script:</span>
          <span className="text-indigo-400/80">Traditional Physics AST Engine</span>
        </div>
        <textarea
          value={dslInput}
          onChange={(e) => setDslInput(e.target.value)}
          className="w-full h-24 bg-slate-950/80 border border-slate-800/80 rounded p-3 text-xs font-mono text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 resize-none leading-relaxed"
          placeholder="Enter GAA DSL Command Script..."
        />
      </div>

      {/* Compiler Log Output */}
      {logs.length > 0 && (
        <div className="bg-slate-950/90 border border-slate-800/60 rounded p-3 font-mono text-[10px] space-y-1 max-h-24 overflow-y-auto">
          {logs.map((log, idx) => (
            <div
              key={idx}
              className={`${
                log.includes("[SUCCESS]")
                  ? "text-indigo-400"
                  : log.includes("[OK]")
                  ? "text-indigo-300"
                  : log.includes("[SYSTEM]")
                  ? "text-slate-400 font-bold"
                  : "text-slate-400"
              }`}
            >
              {log}
            </div>
          ))}
        </div>
      )}

      {/* Physical Attribute Toggles directly mapping DSL parameters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Row 1 */}
        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-indigo-400">api_tri_heteo</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              異質多閘極阻障層 (Si-SiGe-Ge)，抑止源汲極量子隧穿漏電。
            </div>
          </div>
          <button
            onClick={() => toggleParam("apiTriHeteo", !dsl.apiTriHeteo)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.apiTriHeteo ? "bg-indigo-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.apiTriHeteo ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Grid Setting */}
        <div className="p-3 bg-slate-950/30 border border-slate-800/40 rounded space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200 font-mono text-indigo-400">UI_grid_mesh</span>
            <span className="text-[9px] font-mono text-slate-400 uppercase">{dsl.uiGrid}</span>
          </div>
          <div className="grid grid-cols-3 gap-1">
            {(["uniform", "diverged", "boiled-slit"] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => toggleParam("uiGrid", mode)}
                className={`text-[9px] py-1 px-1.5 rounded font-mono transition-all ${
                  dsl.uiGrid === mode
                    ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/40"
                    : "bg-slate-900 text-slate-400 border border-slate-800/60 hover:bg-slate-800"
                }`}
              >
                {mode === "boiled-slit" ? "Boiled Slit" : mode === "diverged" ? "Diverged" : "Uniform"}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2 */}
        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-sky-400">eco_anchored</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              自洽薛丁格-帕松邊界錨定求解 (Schrödinger-Poisson Screen)。
            </div>
          </div>
          <button
            onClick={() => toggleParam("ecoAnchored", !dsl.ecoAnchored)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.ecoAnchored ? "bg-sky-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.ecoAnchored ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-rose-400">lux_insuffice_defect</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              界面缺陷能級分析，模擬缺陷輔助隧穿 (Trap-Assisted Leakage)。
            </div>
          </div>
          <button
            onClick={() => toggleParam("trapAssistedTunneling", !dsl.trapAssistedTunneling)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.trapAssistedTunneling ? "bg-rose-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.trapAssistedTunneling ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Row 3 */}
        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-purple-400">iRABBIT.double_chain</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              雙鏈緊束縛 (Tight-binding) 傳輸求解，顯示多重共振能級尖峰。
            </div>
          </div>
          <button
            onClick={() => toggleParam("doubleChainSolver", !dsl.doubleChainSolver)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.doubleChainSolver ? "bg-purple-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.doubleChainSolver ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-amber-400">mono_frequency_matched</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              鎖定特定單頻共振能級以過濾和追蹤載流子隧穿效率。
            </div>
          </div>
          <button
            onClick={() => toggleParam("monoFrequencyMatched", !dsl.monoFrequencyMatched)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.monoFrequencyMatched ? "bg-amber-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.monoFrequencyMatched ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Batch sweeping panel toggle */}
        <div className="flex items-center justify-between p-3 bg-slate-950/30 border border-slate-800/40 rounded md:col-span-2">
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
              <span className="text-teal-400">set_plant_queue (批次參數掃描)</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              啟用參數多維度掃描與趨勢分析隊列 (Sweep Queue for Gate Length & Oxide Thickness)。
            </div>
          </div>
          <button
            onClick={() => toggleParam("setPlantQueue", !dsl.setPlantQueue)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
              dsl.setPlantQueue ? "bg-teal-500" : "bg-slate-800"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                dsl.setPlantQueue ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
}
