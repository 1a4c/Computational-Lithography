import React from "react";
import { SimulationResult } from "../types";

interface EnergyBandChartProps {
  simulation: SimulationResult;
  gateLength: number;
}

export default function EnergyBandChart({ simulation, gateLength }: EnergyBandChartProps) {
  const {
    xCoords,
    energyBand,
    fermiSource,
    fermiDrain,
    wavefunction,
    transmissionCoeffs,
    energyGrid,
    currentSpectrum
  } = simulation;

  // Layout limits
  const xMin = 0;
  const xMax = 10 + gateLength; // Source is 5nm, Drain is 5nm
  const yMin = -0.8;
  const yMax = 1.6;

  // Chart margins
  const width = 450;
  const height = 240;
  const margin = { top: 30, right: 30, bottom: 40, left: 45 };

  // Mapping coordinate functions
  const mapX = (xVal: number) => {
    return margin.left + ((xVal - xMin) / (xMax - xMin)) * (width - margin.left - margin.right);
  };

  const mapY = (yVal: number) => {
    return margin.top + ((yMax - yVal) / (yMax - yMin)) * (height - margin.top - margin.bottom);
  };

  // Build conduction band path
  const bandPoints = xCoords.map((x, idx) => `${mapX(x)},${mapY(energyBand[idx])}`).join(" ");
  const bandPath = `M ${bandPoints}`;

  // Shade direct tunneling region under the barrier and above Fermi levels
  // We can fill the area from energy E_fs to Ec(x) where Ec(x) > E_fs
  const shadePathPoints: string[] = [];
  for (let i = 0; i < xCoords.length; i++) {
    const x = xCoords[i];
    const Ec = energyBand[i];
    const floor = Math.max(fermiSource, fermiDrain);
    if (Ec > floor) {
      shadePathPoints.push(`${mapX(x)},${mapY(Ec)}`);
    }
  }
  // Connect the shade points to form a closed polygon along the floor level
  let sPath = "";
  if (shadePathPoints.length > 0) {
    const xStart = xCoords[energyBand.findIndex((ec) => ec > Math.max(fermiSource, fermiDrain))];
    const xEnd = xCoords[xCoords.length - 1 - [...energyBand].reverse().findIndex((ec) => ec > Math.max(fermiSource, fermiDrain))];
    
    sPath = `M ${mapX(xStart)},${mapY(Math.max(fermiSource, fermiDrain))} ` +
            shadePathPoints.join(" L ") +
            ` L ${mapX(xEnd)},${mapY(Math.max(fermiSource, fermiDrain))} Z`;
  }

  // Find peak energy of conduction band barrier
  const peakBarrierEnergy = Math.max(...energyBand);
  const peakBarrierIdx = energyBand.indexOf(peakBarrierEnergy);
  const peakBarrierX = xCoords[peakBarrierIdx];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* 1. Main Energy Band Plot (Left side) */}
      <div id="energy-band-plot" className="lg:col-span-8 bg-slate-900/40 border border-slate-800 rounded p-5 backdrop-blur-md">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold tracking-wide text-slate-200">
              能帶圖與電子波包分布
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Energy Band Diagram & Wavefunction Quantum Confinement
            </p>
          </div>
          <div className="flex gap-2">
            <span className="text-[10px] bg-sky-500/10 border border-sky-400/20 text-sky-300 font-mono px-2 py-0.5 rounded">
              E1, E2 離散束縛態
            </span>
            <span className="text-[10px] bg-rose-500/10 border border-rose-400/20 text-rose-300 font-mono px-2 py-0.5 rounded">
              WKB 隧穿域
            </span>
          </div>
        </div>

        <div className="relative border border-slate-800/60 rounded bg-slate-950/60 p-1 flex items-center justify-center overflow-hidden">
          <svg className="w-full h-auto select-none" viewBox={`0 0 ${width} ${height}`}>
            <defs>
              <linearGradient id="bandGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ef4444" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#ef4444" stopOpacity="0.0" />
              </linearGradient>
              <pattern id="tunnelStripes" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="8" stroke="#ef4444" strokeWidth="1.5" opacity="0.15" />
              </pattern>
            </defs>

            {/* Grid ticks */}
            <g stroke="#1e293b" strokeWidth="0.5">
              {[0, 0.4, 0.8, 1.2, 1.6].map((gridY, i) => (
                <line key={i} x1={margin.left} y1={mapY(gridY)} x2={width - margin.right} y2={mapY(gridY)} />
              ))}
            </g>

            {/* Y Axis text label */}
            <g fontSize="8" fill="#64748b" fontFamily="monospace">
              {[0, 0.4, 0.8, 1.2].map((gridY, i) => (
                <text key={i} x={margin.left - 8} y={mapY(gridY) + 3} textAnchor="end">
                  {gridY.toFixed(1)} eV
                </text>
              ))}
              <text x={margin.left - 8} y={mapY(1.5) + 3} textAnchor="end" fill="#f43f5e" fontWeight="bold">
                1.5 eV
              </text>
            </g>

            {/* Junction Boundary Lines */}
            <line
              x1={mapX(5.0)}
              y1={margin.top}
              x2={mapX(5.0)}
              y2={height - margin.bottom}
              stroke="#334155"
              strokeWidth="1"
              strokeDasharray="2 3"
            />
            <line
              x1={mapX(5.0 + gateLength)}
              y1={margin.top}
              x2={mapX(5.0 + gateLength)}
              y2={height - margin.bottom}
              stroke="#334155"
              strokeWidth="1"
              strokeDasharray="2 3"
            />

            {/* Direct SDT Tunneling Region Shaded Pattern */}
            {sPath && <path d={sPath} fill="url(#tunnelStripes)" />}

            {/* Fermi levels */}
            {/* Source Fermi Efs */}
            <line
              x1={margin.left}
              y1={mapY(fermiSource)}
              x2={mapX(5.0)}
              y2={mapY(fermiSource)}
              stroke="#38bdf8"
              strokeWidth="1.5"
              strokeDasharray="3 2"
            />
            <text x={margin.left + 5} y={mapY(fermiSource) - 5} fill="#38bdf8" fontSize="8" fontFamily="monospace">
              E_fs (源極)
            </text>

            {/* Drain Fermi Efd */}
            <line
              x1={mapX(5.0 + gateLength)}
              y1={mapY(fermiDrain)}
              x2={width - margin.right}
              y2={mapY(fermiDrain)}
              stroke="#60a5fa"
              strokeWidth="1.5"
              strokeDasharray="3 2"
            />
            <text x={width - margin.right - 5} y={mapY(fermiDrain) - 5} fill="#60a5fa" fontSize="8" fontFamily="monospace" textAnchor="end">
              E_fd (汲極)
            </text>

            {/* Conduction band profile Ec(x) */}
            <path d={bandPath} fill="none" stroke="#ef4444" strokeWidth="2.5" />
            <text x={mapX(5.0 + gateLength / 2)} y={mapY(peakBarrierEnergy) - 8} fill="#ef4444" fontSize="9" fontWeight="bold" textAnchor="middle">
              E_c (導帶邊緣)
            </text>

            {/* Plot Discrete Quantum Subbands (E1, E2) and Wavefunctions */}
            {wavefunction.map((wf, wfIdx) => {
              const subbandE = wf.energy;
              const subbandY = mapY(subbandE);
              
              // Wavefunction scaling
              const scalePsi = 180; // scale factor to fit visual

              // Build wavefunction path
              const wfPoints = xCoords.map((x, idx) => {
                const psiY = subbandE + wf.psi2[idx] * scalePsi;
                return `${mapX(x)},${mapY(psiY)}`;
              }).join(" ");

              return (
                <g key={wfIdx}>
                  {/* Standing subband horizontal line inside channel */}
                  <line
                    x1={mapX(5.0)}
                    y1={subbandY}
                    x2={mapX(5.0 + gateLength)}
                    y2={subbandY}
                    stroke="#a855f7"
                    strokeWidth="1.2"
                    strokeOpacity="0.8"
                  />
                  {/* Wavefunction curve */}
                  <path
                    d={`M ${wfPoints}`}
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="1.5"
                    strokeOpacity="0.85"
                  />
                  {/* Labels */}
                  <text
                    x={mapX(5.0) - 4}
                    y={subbandY + 3}
                    fill="#a855f7"
                    fontSize="7"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    E{wfIdx + 1}
                  </text>
                  <text
                    x={mapX(5.0 + gateLength) + 4}
                    y={subbandY + 3}
                    fill="#10b981"
                    fontSize="7"
                    fontFamily="monospace"
                    textAnchor="start"
                  >
                    |Ψ_{wfIdx+1}|²
                  </text>
                </g>
              );
            })}

            {/* Tunneling arrow representation under the barrier */}
            {gateLength < 6 && (
              <g>
                <path
                  d={`M ${mapX(4.0)},${mapY(0.2)} L ${mapX(5.0 + gateLength + 1.0)},${mapY(0.2)}`}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                  strokeDasharray="3 2"
                />
                <polygon points={`${mapX(5.0 + gateLength + 1.5)},${mapY(0.2)} ${mapX(5.0 + gateLength + 0.8)},${mapY(0.2) - 3} ${mapX(5.0 + gateLength + 0.8)},${mapY(0.2) + 3}`} fill="#38bdf8" />
                <text
                  x={mapX(5.0 + gateLength / 2)}
                  y={mapY(0.2) + 10}
                  fill="#38bdf8"
                  fontSize="7"
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  Direct SDT Tunneling
                </text>
              </g>
            )}

            {/* Axis labels */}
            <text x={width / 2} y={height - 8} fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="sans-serif">
              傳輸通道座標 x (nm)
            </text>
            <text x={12} y={margin.top - 8} fill="#64748b" fontSize="8" textAnchor="start" fontFamily="sans-serif">
              電子能量 E (eV)
            </text>

            {/* X coordinate labels on bottom */}
            <g fontSize="8" fill="#64748b" fontFamily="monospace">
              <text x={mapX(0)} y={height - 24} textAnchor="middle">0</text>
              <text x={mapX(5.0)} y={height - 24} textAnchor="middle">5.0 (源界)</text>
              <text x={mapX(5.0 + gateLength)} y={height - 24} textAnchor="middle">{(5.0 + gateLength).toFixed(1)} (汲界)</text>
              <text x={mapX(xMax)} y={height - 24} textAnchor="middle">{xMax.toFixed(1)}</text>
            </g>
          </svg>
        </div>
      </div>

      {/* 2. Transmission & Carrier flow spectrum (Right side) */}
      <div id="transmission-plot" className="lg:col-span-4 bg-slate-900/40 border border-slate-800 rounded p-5 backdrop-blur-md flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-slate-200">
            量子隧穿機率與能譜
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Transmission T(E) & Tunneling Spectrum
          </p>
        </div>

        <div className="relative border border-slate-800/60 rounded bg-slate-950/60 p-1 flex items-center justify-center overflow-hidden my-3">
          <svg className="w-full h-auto select-none" viewBox="0 0 200 240">
            {/* T(E) Plot */}
            <g stroke="#1e293b" strokeWidth="0.5">
              {[0, 0.5, 1.0].map((tVal, i) => {
                const x = 30 + tVal * 140;
                return <line key={i} x1={x} y1={20} x2={x} y2={200} />;
              })}
              {[0, 0.4, 0.8, 1.2, 1.6].map((gridY, i) => {
                const y = 20 + ((1.6 - gridY) / 2.4) * 180;
                return <line key={i} x1={30} y1={y} x2={170} y2={y} />;
              })}
            </g>

            {/* X Labels (Transmission) */}
            <g fontSize="7" fill="#64748b" fontFamily="monospace" textAnchor="middle">
              <text x={30} y={212}>0</text>
              <text x={100} y={212}>0.5</text>
              <text x={170} y={212}>1.0</text>
              <text x={100} y={224} fill="#94a3b8">隧穿機率 T(E)</text>
            </g>

            {/* Y Labels (Energy) */}
            <g fontSize="7" fill="#64748b" fontFamily="monospace" textAnchor="end">
              {[0, 0.8, 1.6].map((gridY, i) => {
                const y = 20 + ((1.6 - gridY) / 2.4) * 180;
                return <text key={i} x={24} y={y + 3.5}>{gridY.toFixed(1)}</text>;
              })}
            </g>

            {/* Map functions for T(E) */}
            {(() => {
              const mapEx = (tVal: number) => 30 + tVal * 140;
              const mapEy = (eVal: number) => 20 + ((1.6 - eVal) / 2.4) * 180;

              // Build T(E) line
              const tPoints = transmissionCoeffs
                .map((tc) => `${mapEx(tc.value)},${mapEy(tc.energy)}`)
                .join(" ");

              // Build Current Spectrum line (dI/dE) shaded
              // Max current peak for scaling
              const maxSpectrum = Math.max(...currentSpectrum, 1e-15);
              const specPoints = currentSpectrum.map((spec, idx) => {
                const normalizedVal = (spec / maxSpectrum) * 0.95; // bound to 0-1 range
                return `${mapEx(normalizedVal)},${mapEy(energyGrid[idx])}`;
              });
              
              const specAreaPoints = [
                `30,${mapEy(energyGrid[0])}`,
                ...specPoints,
                `30,${mapEy(energyGrid[energyGrid.length-1])}`
              ].join(" ");

              return (
                <g>
                  {/* Current Spectrum Shaded Area */}
                  <polygon points={specAreaPoints} fill="#38bdf8" fillOpacity="0.25" stroke="#38bdf8" strokeWidth="0.5" />
                  
                  {/* T(E) curve line */}
                  <path d={`M ${tPoints}`} fill="none" stroke="#f43f5e" strokeWidth="1.5" />
                  
                  {/* Level indicators */}
                  <text x={165} y={mapEy(0.2)} fill="#38bdf8" fontSize="7" textAnchor="end" fontFamily="sans-serif">
                    電子傳輸能譜
                  </text>
                  <text x={165} y={mapEy(1.1)} fill="#f43f5e" fontSize="7" textAnchor="end" fontFamily="sans-serif">
                    T(E) 曲線
                  </text>
                </g>
              );
            })()}
          </svg>
        </div>

        <div className="bg-slate-950/40 border border-slate-800/50 rounded p-3 text-[11px] text-slate-400 space-y-1.5 leading-relaxed">
          <p>
            <span className="text-rose-400 font-bold font-mono">■</span> <b>紅色 T(E) 曲線:</b> 當能量低於勢壘峰值時，大於零的機率代表<b>量子隧穿效應</b>的存在。
          </p>
          <p>
            <span className="text-sky-400 font-bold font-mono">■</span> <b>藍色能譜:</b> 顯示載流子傳輸的能量分布。可以明顯看到低能端的隧穿漏電流與高能端的熱發射電流。
          </p>
        </div>
      </div>
    </div>
  );
}
