import React, { useMemo } from "react";
import { DeviceParams, DslState } from "../types";

interface GaaVisualizerProps {
  params: DeviceParams;
  dsl: DslState;
}

export default function GaaVisualizer({ params, dsl }: GaaVisualizerProps) {
  const { gateLength, nanowireDiameter, oxideThickness, channelMaterial } = params;

  // Derive pixel widths based on parameters
  const srcWidth = 70;
  const drnWidth = 70;
  
  // Scale factor: Lg of 2 to 15nm maps to 40px - 180px
  const chanWidth = 40 + ((gateLength - 2) / 13) * 140;
  
  // Scale factor: Nanowire diameter of 2 to 10nm maps to 12px - 60px
  const wireHeight = 12 + ((nanowireDiameter - 2) / 8) * 48;

  // Scale factor: Tox of 0.5 to 3.0nm maps to 4px - 24px
  const oxThickness = 4 + ((oxideThickness - 0.5) / 2.5) * 20;

  // Get material color scheme
  const materialColor = useMemo(() => {
    switch (channelMaterial) {
      case "Ge":
        return { channel: "#8B5CF6", text: "Germanium (Ge)", dark: "#6D28D9" };
      case "InGaAs":
        return { channel: "#10B981", text: "InGaAs (III-V)", dark: "#047857" };
      case "MoS2":
        return { channel: "#F59E0B", text: "MoS₂ (2D Material)", dark: "#D97706" };
      case "Si":
      default:
        return { channel: "#3B82F6", text: "Silicon (Si)", dark: "#1D4ED8" };
    }
  }, [channelMaterial]);

  return (
    <div id="gaa-visualizer" className="bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-slate-200">
            3D 環繞閘極 (GAA) 奈米線結構剖面
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            GAA Shell Nanowire Structural Section • {materialColor.text} 通道
          </p>
        </div>
        <div className="flex items-center gap-2">
          {dsl.apiTriHeteo && (
            <span className="text-[10px] bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 font-mono px-2 py-0.5 rounded">
              HETEROACTIVE
            </span>
          )}
          <span className="text-[10px] bg-slate-800 border border-slate-700 text-slate-300 font-mono px-2 py-0.5 rounded">
            Lg={gateLength}nm • D={nanowireDiameter}nm • Tox={oxideThickness}nm
          </span>
        </div>
      </div>

      <div className="relative w-full h-72 flex items-center justify-center border border-slate-800/60 rounded bg-slate-950/60 overflow-hidden">
        {/* Dynamic SVG Visualizer */}
        <svg
          className="w-full h-full select-none"
          viewBox="0 0 420 220"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Gradients */}
            <linearGradient id="gateGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#475569" />
              <stop offset="40%" stopColor="#64748B" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
            <linearGradient id="oxGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#fb7185" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.15" />
            </linearGradient>
            <linearGradient id="srcGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#475569" />
            </linearGradient>
            <radialGradient id="electronGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="1" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="gateLeakGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="1" />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Grid lines to represent diverged vs uniform mesh physically! */}
          <g opacity="0.15">
            {Array.from({ length: dsl.uiGrid === "diverged" ? 30 : 15 }).map((_, i, arr) => {
              const x = 20 + (i / arr.length) * 380;
              return (
                <line
                  key={i}
                  x1={x}
                  y1={10}
                  x2={x}
                  y2={210}
                  stroke="#64748B"
                  strokeWidth={dsl.uiGrid === "diverged" && (i === 5 || i === arr.length - 6) ? "1.5" : "0.5"}
                  strokeDasharray={dsl.uiGrid === "diverged" && (i < 8 || i > arr.length - 9) ? "" : "3 3"}
                />
              );
            })}
          </g>

          {/* Device Core Coordinates Offset for Centering */}
          {(() => {
            const centerX = 210;
            const centerY = 110;
            
            const xSrc = centerX - chanWidth / 2 - srcWidth;
            const xChan = centerX - chanWidth / 2;
            const xDrn = centerX + chanWidth / 2;

            const yWireTop = centerY - wireHeight / 2;
            const yOxTop = yWireTop - oxThickness;
            const yGateTop = yOxTop - 25; // 25px gate metal wrapping height

            const yWireBot = centerY + wireHeight / 2;
            const yOxBot = yWireBot + oxThickness;
            const yGateBot = yOxBot + 25;

            return (
              <g>
                {/* 1. Gate Metal (Wrapped Shell) */}
                <rect
                  x={xChan}
                  y={yGateTop}
                  width={chanWidth}
                  height={yGateBot - yGateTop}
                  fill="url(#gateGrad)"
                  rx="6"
                  opacity="0.85"
                  className="transition-all duration-300"
                />
                
                {/* 2. Gate Metal Ring details (3D look) */}
                <path
                  d={`M ${xChan},${centerY} L ${xDrn},${centerY}`}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />

                {/* 3. High-K Dielectric Shell (Tox) */}
                <rect
                  x={xChan}
                  y={yOxTop}
                  width={chanWidth}
                  height={yOxBot - yOxTop}
                  fill="url(#oxGrad)"
                  stroke="#f43f5e"
                  strokeWidth="0.75"
                  strokeOpacity="0.4"
                  className="transition-all duration-300"
                />

                {/* 4. Source Region (Highly n+ doped) */}
                <rect
                  x={xSrc}
                  y={yWireTop - 12} // slightly taller for contact pad representation
                  width={srcWidth}
                  height={wireHeight + 24}
                  fill="url(#srcGrad)"
                  stroke="#475569"
                  strokeWidth="1"
                  rx="3"
                  className="transition-all duration-300"
                />
                
                {/* 5. Drain Region (Highly n+ doped) */}
                <rect
                  x={xDrn}
                  y={yWireTop - 12}
                  width={drnWidth}
                  height={wireHeight + 24}
                  fill="url(#srcGrad)"
                  stroke="#475569"
                  strokeWidth="1"
                  rx="3"
                  className="transition-all duration-300"
                />

                {/* Source/Drain Text Labels */}
                <text
                  x={xSrc + srcWidth / 2}
                  y={centerY + 4}
                  fill="#94a3b8"
                  fontSize="9"
                  fontWeight="bold"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  N+ 源極
                </text>
                <text
                  x={xDrn + drnWidth / 2}
                  y={centerY + 4}
                  fill="#94a3b8"
                  fontSize="9"
                  fontWeight="bold"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  N+ 汲極
                </text>

                {/* 6. Channel Nanowire Core (Gate-All-Around) */}
                <rect
                  x={xChan}
                  y={yWireTop}
                  width={chanWidth}
                  height={wireHeight}
                  fill={materialColor.channel}
                  stroke={materialColor.dark}
                  strokeWidth="1.5"
                  className="transition-all duration-300"
                />

                {/* GAA Cylinder wrap rings to give a 3D ring visual effect */}
                {Array.from({ length: Math.ceil(chanWidth / 25) }).map((_, idx) => {
                  const rX = xChan + 12 + idx * 25;
                  if (rX < xDrn - 8) {
                    return (
                      <path
                        key={idx}
                        d={`M ${rX},${yWireTop} C ${rX + 6},${yWireTop + wireHeight/4} ${rX + 6},${yWireBot - wireHeight/4} ${rX},${yWireBot}`}
                        fill="none"
                        stroke="white"
                        strokeOpacity="0.25"
                        strokeWidth="1"
                      />
                    );
                  }
                  return null;
                })}

                {/* Channel Core Label */}
                <text
                  x={centerX}
                  y={yWireBot + oxThickness + 14}
                  fill={materialColor.channel}
                  fontSize="10"
                  fontWeight="600"
                  textAnchor="middle"
                >
                  {channelMaterial} 奈米線通道
                </text>

                {/* 7. Quantum Tunneling Electron Animations */}
                {/* Direct Source-to-Drain Tunneling (SDT) electrons: only active when Lg is very thin (< 6nm) */}
                {gateLength < 6 && (
                  <g>
                    <line
                      x1={xChan - 10}
                      y1={centerY}
                      x2={xDrn + 10}
                      y2={centerY}
                      stroke="#0284c7"
                      strokeWidth="1.5"
                      strokeDasharray="4 4"
                      className="animate-pulse"
                      opacity="0.6"
                    />
                    {/* Tunneling particles leaking through */}
                    <circle cx={centerX - 15} cy={centerY} r="3" fill="url(#electronGlow)">
                      <animate
                        attributeName="cx"
                        values={`${xChan - 15}; ${xDrn + 15}`}
                        dur="1.2s"
                        repeatCount="indefinite"
                      />
                    </circle>
                    <circle cx={centerX + 15} cy={centerY - 4} r="2.5" fill="url(#electronGlow)">
                      <animate
                        attributeName="cx"
                        values={`${xChan - 15}; ${xDrn + 15}`}
                        dur="0.8s"
                        repeatCount="indefinite"
                        begin="0.3s"
                      />
                    </circle>
                    <text
                      x={centerX}
                      y={centerY - wireHeight/2 - oxThickness - 8}
                      fill="#38bdf8"
                      fontSize="8"
                      fontFamily="monospace"
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      SDT 量子隧穿中! (Lg &lt; 6nm)
                    </text>
                  </g>
                )}

                {/* Gate Tunneling animations if Tox is thin (< 1.2nm) */}
                {oxideThickness < 1.2 && (
                  <g>
                    {/* Glowing dots leaking outward through oxide shell */}
                    <circle cx={centerX} cy={centerY} r="3" fill="url(#gateLeakGlow)">
                      <animate
                        attributeName="cy"
                        values={`${centerY}; ${yGateTop + 5}`}
                        dur="1s"
                        repeatCount="indefinite"
                      />
                      <animate
                        attributeName="opacity"
                        values="1; 0"
                        dur="1s"
                        repeatCount="indefinite"
                      />
                    </circle>
                    <circle cx={centerX - chanWidth/3} cy={centerY} r="2.5" fill="url(#gateLeakGlow)">
                      <animate
                        attributeName="cy"
                        values={`${centerY}; ${yGateBot - 5}`}
                        dur="1.2s"
                        repeatCount="indefinite"
                        begin="0.4s"
                      />
                      <animate
                        attributeName="opacity"
                        values="1; 0"
                        dur="1.2s"
                        repeatCount="indefinite"
                        begin="0.4s"
                      />
                    </circle>
                    <text
                      x={centerX + chanWidth/2 - 10}
                      y={yGateTop + 14}
                      fill="#f43f5e"
                      fontSize="7"
                      fontFamily="monospace"
                      textAnchor="start"
                      fontWeight="bold"
                    >
                      閘極漏電 (Tox={oxideThickness}nm)
                    </text>
                  </g>
                )}

                {/* Gate Metal Wrap indicator arrows */}
                <path
                  d={`M ${centerX - 35},${yGateTop + 8} Q ${centerX},${yGateTop - 12} ${centerX + 35},${yGateTop + 8}`}
                  fill="none"
                  stroke="#cbd5e1"
                  strokeWidth="1"
                  markerEnd="url(#arrow)"
                  strokeDasharray="2 2"
                />
                <text
                  x={centerX}
                  y={yGateTop - 14}
                  fill="#94a3b8"
                  fontSize="8"
                  textAnchor="middle"
                  fontFamily="sans-serif"
                >
                  環繞式閘極 (Gate-All-Around Shell)
                </text>
              </g>
            );
          })()}
        </svg>

        {/* Legend overlays */}
        <div className="absolute bottom-3 left-3 flex gap-3 text-[10px]">
          <div className="flex items-center gap-1.5 text-slate-300 font-mono">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: materialColor.channel }}></span>
            <span>通道 ({channelMaterial})</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-mono">
            <span className="w-2.5 h-2.5 rounded-sm bg-rose-500/50 border border-rose-500"></span>
            <span>閘極氧化層 (High-K)</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-mono">
            <span className="w-2.5 h-2.5 rounded-sm bg-slate-600"></span>
            <span>閘極金屬</span>
          </div>
        </div>

        {/* Mesh Style Indicator */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-slate-900/80 border border-slate-800/80 rounded-full px-2.5 py-0.5 text-[9px] font-mono text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>
            {dsl.uiGrid === "diverged" ? "DIVERGED FINE MESH" : dsl.uiGrid === "boiled-slit" ? "BOILED SLIT GRID" : "UNIFORM MESH"}
          </span>
        </div>
      </div>
    </div>
  );
}
