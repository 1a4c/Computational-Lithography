import React from "react";
import { SimulationResult } from "../types";
import { AlertTriangle, ShieldCheck, Zap, Thermometer, Radio } from "lucide-react";

interface MetricsPanelProps {
  simulation: SimulationResult;
  gateLength: number;
  oxideThickness: number;
}

export default function MetricsPanel({ simulation, gateLength, oxideThickness }: MetricsPanelProps) {
  const {
    sdtLeakage,
    gateLeakage,
    thermionicCurrent,
    totalCurrent,
    ss,
    dibl,
    quantumShift
  } = simulation;

  // Let's approximate On-current vs Off-current for visualization
  // Off-current (at Vg=0V) corresponds to the totalCurrent computed in off-bias
  const iOff = totalCurrent;
  
  // High-performance GAA On-current target
  const iOn = 1.2e-4 * (1.5 / oxideThickness) * (gateLength / 8); 

  const onOffRatio = iOn / (iOff + 1e-18);

  // Status flags for UI warning labels
  const sdtWarning = gateLength < 5;
  const gateWarning = oxideThickness < 1.1;
  const shortChannelWarning = ss > 90 || dibl > 100;

  return (
    <div id="metrics-panel" className="bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md space-y-6">
      <div>
        <h3 className="text-sm font-semibold tracking-wide text-slate-200">
          物理模擬量測與效能指標
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Silicon Device Quantum Metrics & Electrical Parameters
        </p>
      </div>

      {/* Primary KPI grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* On Current */}
        <div className="p-4 bg-slate-950/40 border border-slate-800/50 rounded space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 font-mono">開態電流 (Ion)</span>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-emerald-400">
              {(iOn * 1e6).toFixed(2)}
            </span>
            <span className="text-xs text-emerald-500">μA</span>
          </div>
          <div className="text-[9px] text-slate-500 font-sans">驅動電流能力</div>
        </div>

        {/* Off Current */}
        <div className="p-4 bg-slate-950/40 border border-slate-800/50 rounded space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 font-mono">關態漏電 (Ioff)</span>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-rose-400">
              {(iOff * 1e9).toFixed(2)}
            </span>
            <span className="text-xs text-rose-500">nA</span>
          </div>
          <div className="text-[9px] text-slate-500 font-sans">待機漏電流</div>
        </div>

        {/* On/Off Ratio */}
        <div className="p-4 bg-slate-950/40 border border-slate-800/50 rounded space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 font-mono">開關比 (Ion/Ioff)</span>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-indigo-400">
              {onOffRatio > 1e6 ? `${(onOffRatio / 1e6).toFixed(1)}M` : onOffRatio.toExponential(1)}
            </span>
          </div>
          <div className="text-[9px] text-slate-500 font-sans">開關調變能力</div>
        </div>

        {/* Subthreshold Swing */}
        <div className="p-4 bg-slate-950/40 border border-slate-800/50 rounded space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 font-mono">次臨界擺幅 (SS)</span>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-amber-400">
              {ss.toFixed(1)}
            </span>
            <span className="text-xs text-amber-500">mV/d</span>
          </div>
          <div className="text-[9px] text-slate-500 font-sans">理論極限: 60 mV/dec</div>
        </div>
      </div>

      {/* Detailed Leakage Component Speeds */}
      <div className="space-y-4">
        <h4 className="text-xs font-semibold text-slate-300">
          漏電流物理成分細分 (Leakage Components)
        </h4>

        <div className="space-y-3">
          {/* Source-to-Drain Direct Tunneling (SDT) */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">1. 源汲極直接量子穿隧 (SDT)</span>
              <span className="text-rose-400 font-semibold font-mono">{(sdtLeakage * 1e9).toFixed(3)} nA</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800/50">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  sdtWarning ? "bg-rose-500" : "bg-indigo-500"
                }`}
                style={{ width: `${Math.min(100, (sdtLeakage / (totalCurrent + 1e-20)) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[9px] text-slate-500 font-sans">
              <span>短通道直接量子隧穿漏電</span>
              <span className={sdtWarning ? "text-rose-400 font-medium" : "text-emerald-500"}>
                {sdtWarning ? "⚠️ 嚴重量子穿隧 (Lg < 5nm)" : "✓ 量子隧穿抑制優化"}
              </span>
            </div>
          </div>

          {/* Gate Oxide Leakage */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">2. 閘極高介電層穿隧 (Gate Oxide Leakage)</span>
              <span className="text-rose-400 font-semibold font-mono">{(gateLeakage * 1e12).toFixed(1)} pA</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800/50">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  gateWarning ? "bg-red-500 animate-pulse" : "bg-amber-500"
                }`}
                style={{ width: `${Math.min(100, (gateLeakage / (totalCurrent + 1e-20)) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[9px] text-slate-500 font-sans">
              <span>氧化層 Direct/FN 隧穿</span>
              <span className={gateWarning ? "text-red-400 font-medium" : "text-emerald-500"}>
                {gateWarning ? "⚠️ 極薄氧化層穿隧 (Tox < 1.1nm)" : "✓ 氧化層能障安全"}
              </span>
            </div>
          </div>

          {/* Thermionic Current */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">3. 越能障熱發射漏電 (Thermionic Emission)</span>
              <span className="text-indigo-400 font-semibold font-mono">{(thermionicCurrent * 1e9).toFixed(3)} nA</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800/50">
              <div
                className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (thermionicCurrent / (totalCurrent + 1e-20)) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[9px] text-slate-500 font-sans">
              <span>經典越障熱飽和電流</span>
              <span>佔漏電比例: {((thermionicCurrent / (totalCurrent + 1e-20)) * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Physics properties block */}
      <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-800/40">
        <div className="flex items-start gap-2 bg-slate-950/20 border border-slate-800/40 rounded p-3">
          <Radio className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
          <div>
            <div className="text-[10px] font-semibold text-slate-400 font-mono">量子局限能階偏移 (ΔEq)</div>
            <div className="text-xs font-bold font-mono text-indigo-300 mt-0.5">
              {(quantumShift * 1000).toFixed(1)} meV
            </div>
            <div className="text-[8px] text-slate-500 mt-0.5">奈米通道能帶加寬效應</div>
          </div>
        </div>

        <div className="flex items-start gap-2 bg-slate-950/20 border border-slate-800/40 rounded p-3">
          <AlertTriangle className={`w-4 h-4 mt-0.5 shrink-0 ${shortChannelWarning ? "text-amber-400" : "text-emerald-400"}`} />
          <div>
            <div className="text-[10px] font-semibold text-slate-400 font-mono">汲極誘發勢壘降低 (DIBL)</div>
            <div className="text-xs font-bold font-mono text-slate-200 mt-0.5">
              {dibl.toFixed(1)} mV/V
            </div>
            <div className="text-[8px] text-slate-500 mt-0.5">
              {shortChannelWarning ? "⚠️ 短通道效應明顯" : "✓ 閘極靜電控制優異"}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
