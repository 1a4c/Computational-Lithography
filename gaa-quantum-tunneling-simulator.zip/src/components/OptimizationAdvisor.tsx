import React, { useState } from "react";
import { DeviceParams, DslState, OptimizationAdvice } from "../types";
import { Sparkles, Brain, ArrowRight, Zap, RefreshCw, ChevronRight } from "lucide-react";

interface OptimizationAdvisorProps {
  params: DeviceParams;
  dsl: React.Dispatch<React.SetStateAction<DslState>>;
  setParams: React.Dispatch<React.SetStateAction<DeviceParams>>;
  sdtLeakage: number;
  gateLeakage: number;
  thermionicCurrent: number;
  ss: number;
  dibl: number;
}

export default function OptimizationAdvisor({
  params,
  setParams,
  sdtLeakage,
  gateLeakage,
  thermionicCurrent,
  ss,
  dibl
}: OptimizationAdvisorProps) {
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState<OptimizationAdvice | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchAdvice = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/optimize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          gateLength: params.gateLength,
          nanowireDiameter: params.nanowireDiameter,
          oxideThickness: params.oxideThickness,
          channelMaterial: params.channelMaterial,
          sourceDoping: params.sourceDoping,
          drainBias: params.drainBias,
          gateBias: params.gateBias,
          sdtLeakage,
          gateLeakage,
          thermionicCurrent,
          onOffRatio: (1.2e-4 * (1.5 / params.oxideThickness) * (params.gateLength / 8)) / (sdtLeakage + gateLeakage + thermionicCurrent),
          ss,
          dibl,
          dslState: {
            apiTriHeteo: true,
            uiGrid: "diverged"
          }
        })
      });

      if (!response.ok) {
        throw new Error("無法連接至 Gemini 物理專家。請確認您的 GEMINI_API_KEY 已於 Settings > Secrets 設定完畢。");
      }

      const data = await response.json();
      setAdvice(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "模擬優化諮詢時發生錯誤。");
    } finally {
      setLoading(false);
    }
  };

  const applyOptimalParameters = () => {
    if (!advice) return;
    const { gateLength, nanowireDiameter, oxideThickness, channelMaterial } = advice.optimalParameters;
    
    setParams((prev) => ({
      ...prev,
      gateLength,
      nanowireDiameter,
      oxideThickness,
      channelMaterial: channelMaterial as any
    }));
  };

  return (
    <div id="optimization-advisor" className="bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Brain className="text-indigo-400 w-5 h-5" />
          <div>
            <h3 className="text-sm font-semibold tracking-wide text-slate-200">
              Gemini 物理學家與通道優化建議
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              AI-Powered GAA Device Physics Consultant & Material Advisor
            </p>
          </div>
        </div>
        <button
          onClick={fetchAdvice}
          disabled={loading}
          className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-700 to-indigo-600 hover:from-indigo-600 hover:to-indigo-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-slate-100 rounded text-xs font-bold transition-all shadow-lg shadow-indigo-500/10"
        >
          {loading ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5 fill-current text-amber-300" />
          )}
          <span>啟動 Gemini AI 物理專家諮詢</span>
        </button>
      </div>

      {error && (
        <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs rounded leading-relaxed">
          {error}
        </div>
      )}

      {/* Advice Display Area */}
      {advice ? (
        <div className="space-y-6 animate-fade-in">
          {/* Analysis section */}
          <div className="bg-slate-950/40 border border-slate-800/60 rounded p-4 space-y-2">
            <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider font-mono">
              [ 1. 量子隧穿物理與靜電抑制分析 ]
            </div>
            <div className="text-slate-300 text-xs leading-relaxed whitespace-pre-line font-sans">
              {advice.analysis}
            </div>
          </div>

          {/* Recommendations cards */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider font-mono">
              [ 2. 結構及高介電堆疊建議 ]
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {advice.recommendations.map((rec, idx) => (
                <div key={idx} className="p-3 bg-slate-950/30 border border-slate-800/40 rounded space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200">{rec.title}</span>
                    <span
                      className={`text-[8px] font-mono px-1.5 py-0.5 rounded-sm font-bold uppercase ${
                        rec.impact === "High"
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : rec.impact === "Medium"
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                      }`}
                    >
                      {rec.impact} Impact
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{rec.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Optimized Parameters Comparison Block */}
          <div className="bg-gradient-to-br from-indigo-950/30 to-slate-950/30 border border-indigo-900/30 rounded p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-2 text-left w-full md:w-auto">
              <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider font-mono block">
                [ 3. 建議優化物理參數對比 ]
              </span>
              <div className="flex flex-wrap gap-4 text-xs">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 block font-mono">通道材料:</span>
                  <span className="font-bold text-slate-200 font-mono">
                    {params.channelMaterial} <ArrowRight className="inline w-3 h-3 text-slate-500 mx-1" /> {advice.optimalParameters.channelMaterial}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 block font-mono">閘極長度 (Lg):</span>
                  <span className="font-bold text-slate-200 font-mono">
                    {params.gateLength}nm <ArrowRight className="inline w-3 h-3 text-slate-500 mx-1" /> {advice.optimalParameters.gateLength}nm
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 block font-mono">通道直徑 (D):</span>
                  <span className="font-bold text-slate-200 font-mono">
                    {params.nanowireDiameter}nm <ArrowRight className="inline w-3 h-3 text-slate-500 mx-1" /> {advice.optimalParameters.nanowireDiameter}nm
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-400 block font-mono">氧化層 (Tox):</span>
                  <span className="font-bold text-slate-200 font-mono">
                    {params.oxideThickness}nm <ArrowRight className="inline w-3 h-3 text-slate-500 mx-1" /> {advice.optimalParameters.oxideThickness}nm
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={applyOptimalParameters}
              className="w-full md:w-auto flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 rounded text-xs font-bold transition-all"
            >
              <Zap className="w-3.5 h-3.5 fill-current text-yellow-300 animate-bounce" />
              <span>一鍵套用優化參數</span>
            </button>
          </div>

          {/* Optimized DSL Output Section */}
          <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded space-y-2 font-mono text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-indigo-400 font-semibold">[ 4. 推薦優化 DSL 陳述式 ]</span>
              <span className="text-slate-500 text-[9px]">GAA SOLVER AST</span>
            </div>
            <div className="bg-slate-900 border border-slate-800/60 p-2.5 rounded text-indigo-300 whitespace-pre-wrap select-all">
              {advice.dslOptimized}
            </div>
          </div>
        </div>
      ) : (
        <div className="border border-dashed border-slate-800 rounded py-12 flex flex-col items-center justify-center text-center px-4">
          <Brain className="w-10 h-10 text-slate-700 mb-3 animate-pulse" />
          <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
            點擊上方「<b>啟動 Gemini AI 物理專家諮詢</b>」按鈕，讓 Gemini 分析您當前 GAA 電晶體的量子隧穿漏電情況，並獲取多維度的結構優化與材料配比指南。
          </p>
        </div>
      )}
    </div>
  );
}
