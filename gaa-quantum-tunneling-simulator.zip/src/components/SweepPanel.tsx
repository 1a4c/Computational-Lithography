import React, { useState, useMemo } from "react";
import { DeviceParams, DslState } from "../types";
import { runSweepSweep } from "../lib/simulator";
import { BarChart3, ChevronRight, Zap } from "lucide-react";

interface SweepPanelProps {
  params: DeviceParams;
  dsl: DslState;
}

export default function SweepPanel({ params, dsl }: SweepPanelProps) {
  const [sweepParameter, setSweepParameter] = useState<"gateLength" | "oxideThickness" | "nanowireDiameter">("gateLength");

  // Determine sweep values based on parameter
  const sweepValues = useMemo(() => {
    if (sweepParameter === "gateLength") {
      return [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    } else if (sweepParameter === "oxideThickness") {
      return [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.3, 2.5, 2.7, 2.9, 3.0];
    } else {
      return [2, 3, 4, 5, 6, 7, 8, 9, 10];
    }
  }, [sweepParameter]);

  // Run the batch simulation sweeps
  const sweepResults = useMemo(() => {
    return runSweepSweep(sweepParameter, sweepValues, params, dsl);
  }, [sweepParameter, sweepValues, params, dsl]);

  // SVG Chart Plot Setup
  const width = 500;
  const height = 180;
  const margin = { top: 20, right: 30, bottom: 35, left: 55 };

  // Extents for scaling
  const pMin = sweepValues[0];
  const pMax = sweepValues[sweepValues.length - 1];

  const offCurrents = sweepResults.map((r) => r.totalOffCurrent);
  const minOff = Math.min(...offCurrents, 1e-12);
  const maxOff = Math.max(...offCurrents, 1e-6);

  // We will plot Off-state leakage in Logarithmic scale because current spans decades (nA to uA)!
  // Log10 helper
  const log10 = (v: number) => Math.log10(v);
  const logMin = log10(minOff);
  const logMax = log10(maxOff);

  const mapX = (v: number) => {
    return margin.left + ((v - pMin) / (pMax - pMin)) * (width - margin.left - margin.right);
  };

  const mapYLog = (v: number) => {
    const logVal = log10(v || 1e-18);
    // bound between logMin and logMax
    const fraction = (logMax - logVal) / (logMax - logMin);
    return margin.top + fraction * (height - margin.top - margin.bottom);
  };

  // Build Off-current line points
  const linePoints = sweepResults
    .map((r) => `${mapX(r.parameterValue)},${mapYLog(r.totalOffCurrent)}`)
    .join(" ");

  // Build SDT-only leakage line points
  const sdtPoints = sweepResults
    .map((r) => `${mapX(r.parameterValue)},${mapYLog(r.sdtCurrent)}`)
    .join(" ");

  return (
    <div id="sweep-panel" className="bg-slate-900/40 border border-slate-800 rounded p-6 backdrop-blur-md space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BarChart3 className="text-indigo-400 w-5 h-5" />
          <div>
            <h3 className="text-sm font-semibold tracking-wide text-slate-200">
              `set_plant_queue` 批次參數掃描隊列
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Automated Batch Sweeping & Device Scaling Trajectory
            </p>
          </div>
        </div>

        {/* Sweep Selector Buttons */}
        <div className="flex items-center bg-slate-950/60 border border-slate-800/80 rounded p-1 gap-1">
          <button
            onClick={() => setSweepParameter("gateLength")}
            className={`text-[10px] px-2.5 py-1 rounded font-bold transition-all ${
              sweepParameter === "gateLength" ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            閘極長度 (Lg)
          </button>
          <button
            onClick={() => setSweepParameter("oxideThickness")}
            className={`text-[10px] px-2.5 py-1 rounded font-bold transition-all ${
              sweepParameter === "oxideThickness" ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            氧化層厚 (Tox)
          </button>
          <button
            onClick={() => setSweepParameter("nanowireDiameter")}
            className={`text-[10px] px-2.5 py-1 rounded font-bold transition-all ${
              sweepParameter === "nanowireDiameter" ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            通道直徑 (D)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Plot view */}
        <div className="md:col-span-8 border border-slate-800/60 rounded bg-slate-950/60 p-2 flex items-center justify-center overflow-hidden">
          <svg className="w-full h-auto select-none" viewBox={`0 0 ${width} ${height}`}>
            {/* Grid line background */}
            <g stroke="#1e293b" strokeWidth="0.5">
              {sweepValues.map((val) => (
                <line key={val} x1={mapX(val)} y1={margin.top} x2={mapX(val)} y2={height - margin.bottom} />
              ))}
              {Array.from({ length: 5 }).map((_, i) => {
                const fraction = i / 4;
                const y = margin.top + fraction * (height - margin.top - margin.bottom);
                return <line key={i} x1={margin.left} y1={y} x2={width - margin.right} y2={y} />;
              })}
            </g>

            {/* Y axis logs labels */}
            <g fontSize="7" fill="#64748b" fontFamily="monospace" textAnchor="end">
              {Array.from({ length: 5 }).map((_, i) => {
                const fraction = i / 4;
                const logVal = logMax - fraction * (logMax - logMin);
                const currentAmps = Math.pow(10, logVal);
                const y = margin.top + fraction * (height - margin.top - margin.bottom);
                return (
                  <text key={i} x={margin.left - 8} y={y + 3.5}>
                    {(currentAmps * 1e9).toExponential(1)} nA
                  </text>
                );
              })}
            </g>

            {/* X Axis labels */}
            <g fontSize="7" fill="#64748b" fontFamily="monospace" textAnchor="middle">
              {sweepValues.filter((_, idx) => idx % 2 === 0).map((val) => (
                <text key={val} x={mapX(val)} y={height - margin.bottom + 14}>
                  {val.toFixed(1)}
                </text>
              ))}
              <text x={width / 2} y={height - 4} fill="#94a3b8">
                掃描參數: {sweepParameter === "gateLength" ? "Lg (nm)" : sweepParameter === "oxideThickness" ? "Tox (nm)" : "Diameter D (nm)"}
              </text>
            </g>

            {/* Plot Lines */}
            <path d={`M ${linePoints}`} fill="none" stroke="#f43f5e" strokeWidth="2" />
            <path d={`M ${sdtPoints}`} fill="none" stroke="#38bdf8" strokeWidth="1.2" strokeDasharray="2 2" />

            {/* Glowing dots */}
            {sweepResults.map((r, idx) => (
              <circle
                key={idx}
                cx={mapX(r.parameterValue)}
                cy={mapYLog(r.totalOffCurrent)}
                r="3"
                fill="#f43f5e"
              />
            ))}

            {/* Legend inside SVG */}
            <g transform={`translate(${width - 150}, ${margin.top})`} fontSize="7" fill="#94a3b8">
              <rect width="110" height="35" fill="#020617" stroke="#1e293b" rx="4" />
              <line x1="8" y1="12" x2="20" y2="12" stroke="#f43f5e" strokeWidth="1.5" />
              <text x={26} y={14}>總關態漏電 (Ioff)</text>

              <line x1="8" y1="24" x2="20" y2="24" stroke="#38bdf8" strokeWidth="1.2" strokeDasharray="2 2" />
              <text x={26} y={26}>隧穿漏電 (Isdt)</text>
            </g>
          </svg>
        </div>

        {/* Sweep Analysis Side-Card */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-slate-950/40 border border-slate-800/40 rounded p-4 space-y-3">
            <h4 className="text-xs font-semibold text-slate-200">物理掃描特徵解讀</h4>
            <div className="text-[11px] text-slate-400 space-y-2 leading-relaxed">
              {sweepParameter === "gateLength" && (
                <p>
                  當閘長 Lg <b>低於 5 奈米</b> 時，源汲極能壘寬度極小，導致電子可直接跨越勢壘產生<b>直接隧穿漏電</b>，漏電電流呈現<b>指數級別暴增</b>！
                </p>
              )}
              {sweepParameter === "oxideThickness" && (
                <p>
                  當氧化層厚 Tox <b>低於 1.2 奈米</b> 時，高介電層的物理厚度不足以抑制閘極直接量子隧穿，引發嚴重的<b>閘極漏電流</b>，影響靜電耦合。
                </p>
              )}
              {sweepParameter === "nanowireDiameter" && (
                <p>
                  通道直徑 D越小，量子局限效應 (Quantum Confinement) 越顯著，使通道等效帶隙加寬、能階上移，能起到抑止隧穿的有利效果！
                </p>
              )}
              <div className="flex items-center gap-1.5 text-indigo-400 text-[10px] font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping"></span>
                <span>DSL 批次模擬隊列運行正常</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
