import { DeviceParams, SimulationResult, DslState, SweepResultPoint } from "../types";

// Physical constants
const hbar = 1.0545718e-34; // J.s
const m0 = 9.10938356e-31; // kg
const q = 1.60217663e-19; // C
const kb = 1.380649e-23; // J/K
const eps0 = 8.854187817e-12; // F/m

export function runGaaSimulation(params: DeviceParams, dsl: DslState): SimulationResult {
  const {
    gateLength,
    nanowireDiameter,
    oxideThickness,
    channelMaterial,
    sourceDoping,
    drainBias,
    gateBias,
    gateWorkFunction,
    temperature
  } = params;

  // 1. Material properties setup
  let mEffective = 0.19; // silicon transverse mass
  let epsChannel = 11.7;
  let bandgap = 1.12;

  switch (channelMaterial) {
    case "Ge":
      mEffective = 0.082;
      epsChannel = 16.0;
      bandgap = 0.66;
      break;
    case "InGaAs":
      mEffective = 0.041;
      epsChannel = 13.9;
      bandgap = 0.74;
      break;
    case "MoS2":
      mEffective = 0.45;
      epsChannel = 7.0;
      bandgap = 1.8;
      break;
    case "Si":
    default:
      mEffective = 0.19;
      epsChannel = 11.7;
      bandgap = 1.12;
      break;
  }

  // 2. Quantum confinement energy shift (nanowire 1D subband shift)
  // Delta Eq = 5.783 * hbar^2 / (2 * m* * R^2)
  // Simplified formula: Delta Eq (eV) ~ 0.376 / ( (mEffective) * D_nm^2 )
  const R_nm = nanowireDiameter / 2;
  let quantumShift = 0.376 / (mEffective * (nanowireDiameter * nanowireDiameter));
  
  if (channelMaterial === "MoS2") {
    // 2D materials have different confinement along thickness (usually atomically thin, less sensitive to diameter)
    quantumShift = 0.05;
  }

  // Heterostructure band offset modifier if DSL apiTriHeteo is enabled
  let sourceOffset = 0;
  let drainOffset = 0;
  let channelOffset = 0;
  if (dsl.apiTriHeteo) {
    // Si/SiGe/Ge heterostructure effect: raises channel barrier relative to source/drain
    sourceOffset = -0.15;
    drainOffset = -0.25;
    channelOffset = 0.1;
  }

  // 3. Grid coordinates setup (nm)
  const X_src = 5.0;
  const X_chan = gateLength;
  const X_drn = 5.0;
  const X_max = X_src + X_chan + X_drn;
  
  // Grid resolution: check if DSL uniform vs diverged refined is active
  let N_points = 60;
  if (dsl.uiGrid === "diverged") {
    N_points = 100; // Density increase for diverged mesh grid near interfaces
  } else if (dsl.uiGrid === "boiled-slit") {
    N_points = 80;
  }

  const xCoords: number[] = [];
  for (let i = 0; i < N_points; i++) {
    if (dsl.uiGrid === "diverged") {
      // Diverged mesh: dense near junctions (x = 5nm and x = 5 + Lg)
      const fraction = i / (N_points - 1);
      // Custom mapping to squeeze points around junctions
      let x = fraction * X_max;
      const j1 = X_src;
      const j2 = X_src + X_chan;
      
      // Squeeze function near interfaces
      if (x < j1) {
        x = j1 * Math.pow(x / j1, 1.5);
      } else if (x > j2) {
        x = j2 + (X_max - j2) * Math.pow((x - j2) / (X_max - j2), 1.5);
      } else {
        const mid = (j1 + j2) / 2;
        if (x < mid) {
          x = j1 + (mid - j1) * Math.pow((x - j1) / (mid - j1), 0.8);
        } else {
          x = j2 - (j2 - mid) * Math.pow((j2 - x) / (j2 - mid), 0.8);
        }
      }
      xCoords.push(x);
    } else {
      // Uniform grid
      xCoords.push((i / (N_points - 1)) * X_max);
    }
  }
  // Sort just in case diverged mesh function is non-monotonic
  xCoords.sort((a, b) => a - b);

  // 4. Calculate scaling length lambda for GAA electrostatic control
  // lambda = sqrt( (eps_sem * D^2 * ln(1 + 2*Tox/D) + eps_ox * D^2) / (8 * eps_ox) )
  const eps_ox = 3.9; // SiO2 base (high-k EOT used for Tox directly, so eps_ox = 3.9)
  const logTerm = Math.log(1 + (2 * oxideThickness) / nanowireDiameter);
  const lambda = Math.sqrt(
    (epsChannel * nanowireDiameter * nanowireDiameter * logTerm + eps_ox * nanowireDiameter * nanowireDiameter) /
      (8 * eps_ox)
  );

  // 5. Build energy band profile Ec(x)
  const fermiSource = 0.05 + sourceOffset; // Fermi levels
  const fermiDrain = fermiSource - drainBias + drainOffset;

  const energyBand = xCoords.map((x) => {
    if (x < X_src) {
      // Source region
      return 0 + sourceOffset;
    } else if (x > X_src + X_chan) {
      // Drain region
      return -drainBias + drainOffset;
    } else {
      // Channel region
      // Peak height adjusted by gate workfunction (WF - 4.15 for Si chi)
      const workfunctionDiff = gateWorkFunction - 4.15;
      const phi_bi = 0.5 + workfunctionDiff; // built-in potential barrier
      
      // Confinement raises barrier
      let V_barrier_peak = phi_bi + quantumShift + channelOffset;
      
      // Gate bias pulls barrier down
      const eta = 0.85; // Gate control efficiency
      const gateOverdrive = Math.max(0, gateBias - 0.25);
      V_barrier_peak -= eta * gateOverdrive;

      // Ensure the barrier doesn't sink fully below source unless gate is extremely high
      V_barrier_peak = Math.max(-0.2, V_barrier_peak);

      // Parabolic base barrier along the channel
      const dx = x - (X_src + X_chan / 2);
      const halfL = X_chan / 2;
      let shape = 1 - (dx * dx) / (halfL * halfL);
      shape = Math.max(0, shape);

      let Ec = V_barrier_peak * shape;

      // Drain barrier lowering (DIBL) penetration
      // Modeled using exponential decay sinh((x-X_src)/lambda) / sinh(L_g/lambda)
      const num = Math.sinh((x - X_src) / lambda);
      const den = Math.sinh(X_chan / lambda);
      const drainPotentialTerm = den > 0 ? (num / den) * drainBias : (x / X_chan) * drainBias;
      
      Ec -= drainPotentialTerm;

      return Ec;
    }
  });

  // Self-consistent correction loop (ecoAnchored DSL mode)
  if (dsl.ecoAnchored) {
    // Add charge screening effect: positive gate bias draws electrons into the channel,
    // which screens the gate potential, raising the bottom of the band slightly.
    const screenCoeff = 0.08 * Math.max(0, gateBias - 0.1);
    for (let i = 0; i < N_points; i++) {
      if (xCoords[i] >= X_src && xCoords[i] <= X_src + X_chan) {
        // Simple charge screen contribution
        const distFromJunction = Math.min(xCoords[i] - X_src, X_src + X_chan - xCoords[i]);
        const chargeFactor = Math.sin((Math.PI * (xCoords[i] - X_src)) / X_chan);
        energyBand[i] += screenCoeff * chargeFactor;
      }
    }
  }

  // Trap-assisted defect states (lux_insuffice_event_sensitivity_slots DSL mode)
  if (dsl.trapAssistedTunneling) {
    // Pull down band locally in the middle of the oxide interface to represent trap-assisted states
    const trapX = X_src + X_chan / 2;
    for (let i = 0; i < N_points; i++) {
      const dist = Math.abs(xCoords[i] - trapX);
      if (dist < 1.0) {
        energyBand[i] -= 0.12 * (1 - dist / 1.0); // Create local potential dip
      }
    }
  }

  // Boiled Slit hot-carrier high energy model
  if (dsl.uiGrid === "boiled-slit") {
    // Narrow down the width of the potential to simulate thin "slit" injection
    for (let i = 0; i < N_points; i++) {
      if (xCoords[i] >= X_src && xCoords[i] <= X_src + X_chan) {
        const dx = xCoords[i] - (X_src + X_chan / 2);
        if (Math.abs(dx) > X_chan / 4) {
          energyBand[i] *= 0.5; // sharpen/steepen the potential barrier barrier edges
        }
      }
    }
  }

  // 6. Energy Grid setup for tunneling probability integrations (eV)
  const E_min = -1.0;
  const E_max = 2.0;
  const N_energy = 120;
  const energyGrid: number[] = [];
  for (let i = 0; i < N_energy; i++) {
    energyGrid.push(E_min + (i / (N_energy - 1)) * (E_max - E_min));
  }

  // 7. Calculate transmission coefficient T(E) using WKB approximation
  // T(E) = exp( -2 * integral( sqrt(2 * m* * (Ec(x) - E)) / hbar ) dx )
  const transmissionCoeffs = energyGrid.map((E) => {
    let exponent = 0;
    let isTunneling = false;

    for (let i = 0; i < N_points - 1; i++) {
      const x1 = xCoords[i];
      const x2 = xCoords[i + 1];
      const Ec1 = energyBand[i];
      const Ec2 = energyBand[i + 1];
      const dx_nm = x2 - x1;

      // Average barrier height in this segment
      const Ec_avg = (Ec1 + Ec2) / 2;

      if (Ec_avg > E) {
        isTunneling = true;
        // Convert physical units: energy diff in Joules, dx in meters
        const energyDiffJoules = (Ec_avg - E) * q;
        const dx_meters = dx_nm * 1e-9;
        
        // Integrand = sqrt(2 * m* * (Ec(x) - E)) / hbar
        const integrand = Math.sqrt(2 * mEffective * m0 * energyDiffJoules) / hbar;
        exponent += integrand * dx_meters;
      }
    }

    let T_val = 0;
    if (isTunneling) {
      T_val = Math.exp(-2 * exponent);
    } else {
      // Over-the-barrier: transmission is 1 (classical thermionic emission)
      T_val = 1.0;
    }

    // Enhance trap assisted tunneling around the defect energy if TAT is enabled
    if (dsl.trapAssistedTunneling) {
      const trapE = 0.28; // localized defect energy state (eV)
      const resonanceWidth = 0.03; // narrow tunneling window
      const lorentzian = resonanceWidth / (Math.pow(E - trapE, 2) + Math.pow(resonanceWidth, 2));
      T_val = Math.min(1.0, T_val + 0.15 * lorentzian);
    }

    // Double chain solver resonance mode (resonance tunneling spikes)
    if (dsl.doubleChainSolver) {
      // Generates multiple quantum resonant peaks in the transmission spectrum
      const resonancePeaks = [0.1, 0.35, 0.65];
      let peakEnhancement = 0;
      for (const pr of resonancePeaks) {
        const peakWidth = 0.015;
        const resonantLorentzian = peakWidth / (Math.pow(E - pr, 2) + Math.pow(peakWidth, 2));
        peakEnhancement += 0.4 * resonantLorentzian;
      }
      T_val = Math.min(1.0, T_val + peakEnhancement);
    }

    return { energy: E, value: T_val };
  });

  // 8. Calculate Wavefunctions psi(x)^2 for visual feedback
  // Solve simplified 1D Schrodinger for ground state wavefunctions using finite differences
  const wavefunctionsList: { energy: number; psi2: number[] }[] = [];
  
  // Find top 2 lowest confined state energy levels roughly corresponding to quantum subbands
  // Let's model them as simple standing waves in a quantum well with penetration into barriers
  const barrierPeakVal = Math.max(...energyBand);
  const barrierMidIdx = energyBand.indexOf(barrierPeakVal);
  const barrierPeakX = xCoords[barrierMidIdx];

  const subbandEnergies = [
    fermiSource + quantumShift,
    fermiSource + 3 * quantumShift
  ];

  for (let sIdx = 0; sIdx < subbandEnergies.length; sIdx++) {
    const E_sub = subbandEnergies[sIdx];
    const psi2 = xCoords.map((x) => {
      // Confined inside channel, decays exponentially into S/D barriers
      if (x < X_src) {
        const kappa = Math.sqrt(2 * mEffective * m0 * Math.max(0, 0.4 - E_sub) * q) / hbar;
        const dist = X_src - x;
        return Math.pow(Math.sin((sIdx + 1) * Math.PI * 0.1), 2) * Math.exp(-2 * kappa * dist * 1e-9);
      } else if (x > X_src + X_chan) {
        const kappa = Math.sqrt(2 * mEffective * m0 * Math.max(0, 0.4 - E_sub) * q) / hbar;
        const dist = x - (X_src + X_chan);
        return Math.pow(Math.sin((sIdx + 1) * Math.PI * 0.9), 2) * Math.exp(-2 * kappa * dist * 1e-9);
      } else {
        // standing wave inside channel
        const fraction = (x - X_src) / X_chan;
        // Quantum standing wave: sin(n * pi * fraction)
        return Math.pow(Math.sin((sIdx + 1) * Math.PI * fraction), 2);
      }
    });

    // Normalize wavefunction psi^2
    const sum = psi2.reduce((acc, v) => acc + v, 0);
    const normalizedPsi2 = psi2.map((v) => (sum > 0 ? v / sum : 0));

    wavefunctionsList.push({
      energy: E_sub,
      psi2: normalizedPsi2
    });
  }

  // 9. Calculate SDT Tunneling current and Thermionic emission current
  // Landauer Formula: I = 2q/h * integral( T(E) * (fs - fd) dE )
  const h_planck = 6.62607015e-34; // J.s
  const prefactor = (2 * q * q) / h_planck; // Landauer current prefactor (approx for 1D channel)

  let sdtLeakage = 0;
  let thermionicCurrent = 0;
  const currentSpectrum: number[] = [];

  const dE = energyGrid[1] - energyGrid[0];
  const peakEc = Math.max(...energyBand);

  for (let i = 0; i < N_energy; i++) {
    const E = energyGrid[i];
    const T_val = transmissionCoeffs[i].value;

    // Fermi-Dirac distributions
    const fs = 1 / (1 + Math.exp(((E - fermiSource) * q) / (kb * temperature)));
    const fd = 1 / (1 + Math.exp(((E - fermiDrain) * q) / (kb * temperature)));
    const diff = fs - fd;

    // Split current contribution into direct tunneling (below peak barrier) vs thermionic (above barrier)
    const dI = prefactor * T_val * diff * dE * 1e-6; // Scale down to fit standard nanowire specs (A)

    currentSpectrum.push(dI);

    if (E < peakEc) {
      sdtLeakage += dI;
    } else {
      thermionicCurrent += dI;
    }
  }

  // 10. Gate oxide tunneling leakage current simulation (Direct/FN oxide leakage)
  // J_gate ~ A * E_ox^2 * exp(-B / E_ox) for FN; Direct tunneling for ultra-thin Tox
  // Electric field in oxide Fox = Vg / Tox
  const Fox = Math.max(0.1, gateBias) / (oxideThickness * 1e-7); // V/cm
  let gateLeakage = 0;
  
  if (oxideThickness < 1.2) {
    // Massive Direct tunneling through high-k layer
    gateLeakage = 1e-11 * Math.pow(1.2 / oxideThickness, 6) * Math.sinh(2 * gateBias);
  } else {
    // Fowler-Nordheim triangular barrier tunneling (very low at thick Tox)
    const A_fn = 1.5e-6;
    const B_fn = 2.5e7;
    gateLeakage = A_fn * Fox * Fox * Math.exp(-B_fn / Fox) * 1e-12;
  }

  // 11. SS & DIBL calculation approximations
  // SS = ln(10) * m * vt
  // DIBL = delta Vth / delta Vd
  const vt = (kb * temperature) / q; // Thermal voltage (0.0259V at 300K)
  const cd = epsChannel * eps0 / (nanowireDiameter * 1e-9);
  const cox = eps_ox * eps0 / (oxideThickness * 1e-9);
  const bodyFactor = 1 + cd / cox;
  
  // Degraded SS if gate control is poor (Tox is large or Lg is short)
  const shortChannelDegradation = Math.exp(-gateLength / (1.8 * lambda));
  const ss = Math.log(10) * vt * bodyFactor * (1 + 4.5 * shortChannelDegradation) * 1000; // mV/dec

  // DIBL increases exponentially as gate control degrades
  const dibl = 150 * shortChannelDegradation * (oxideThickness / 1.0) * (5.0 / nanowireDiameter); // mV/V

  // Calculate total current
  const totalCurrent = sdtLeakage + thermionicCurrent + gateLeakage;

  return {
    xCoords,
    energyBand,
    fermiSource,
    fermiDrain,
    wavefunction: wavefunctionsList,
    transmissionCoeffs,
    energyGrid,
    currentSpectrum,
    sdtLeakage,
    gateLeakage,
    thermionicCurrent,
    totalCurrent,
    ss,
    dibl,
    quantumShift
  };
}

// Perform sweep calculations for the batch run console panel
export function runSweepSweep(
  parameterName: "gateLength" | "oxideThickness" | "nanowireDiameter",
  values: number[],
  baseParams: DeviceParams,
  dsl: DslState
): SweepResultPoint[] {
  return values.map((val) => {
    const testParams = { ...baseParams, [parameterName]: val };
    
    // For sweep, simulate off-state (Vg = 0V) and on-state (Vg = 0.85V)
    const offSim = runGaaSimulation({ ...testParams, gateBias: 0.0 }, dsl);
    const onSim = runGaaSimulation({ ...testParams, gateBias: 0.85 }, dsl);

    return {
      parameterValue: val,
      sdtCurrent: offSim.sdtLeakage,
      gateCurrent: offSim.gateLeakage,
      thermionicCurrent: offSim.thermionicCurrent,
      totalOffCurrent: offSim.totalCurrent,
      totalOnCurrent: onSim.totalCurrent,
      ss: offSim.ss
    };
  });
}
