export interface DslState {
  apiTriHeteo: boolean; // Toggles Triple-Gate Heterostructure Mode (Si-SiGe-Ge)
  uiGrid: "uniform" | "diverged" | "boiled-slit"; // Grid mesh setting & slit potential model
  setPlantQueue: boolean; // Toggles Batch Sweep Queue Panel
  ecoAnchored: boolean; // Toggles Self-Consistent Schrödinger-Poisson Solver
  optimizationActive: boolean; // Toggles multi-objective optimization router
  trapAssistedTunneling: boolean; // Toggles subthreshold trap-assisted tunneling states
  doubleChainSolver: boolean; // Toggles tight-binding double-chain Hamiltonian mode
  monoFrequencyMatched: boolean; // Toggles resonance level selection & filter
  resonantEnergyLevel: number; // The active matched energy level (eV)
}

export interface DeviceParams {
  gateLength: number; // Lg (nm), range: 2 to 15
  nanowireDiameter: number; // D (nm), range: 2 to 10
  oxideThickness: number; // Tox (nm), range: 0.5 to 3.0
  channelMaterial: "Si" | "Ge" | "InGaAs" | "MoS2"; // Semiconductor channel material
  sourceDoping: number; // Nsd (cm^-3), e.g., 1e20
  drainBias: number; // Vd (V), range: 0.0 to 1.2
  gateBias: number; // Vg (V), range: -0.2 to 1.2
  gateWorkFunction: number; // WF (eV), range: 4.0 to 5.2
  temperature: number; // T (K), range: 77 to 450
}

export interface SimulationResult {
  xCoords: number[]; // x along the channel (nm)
  energyBand: number[]; // Ec conduction band edge profile (eV)
  fermiSource: number; // Source Fermi level (eV)
  fermiDrain: number; // Drain Fermi level (eV)
  wavefunction: {
    energy: number;
    psi2: number[]; // |psi(x)|^2 wave probability along x
  }[];
  transmissionCoeffs: { energy: number; value: number }[]; // T(E) vs Energy
  energyGrid: number[]; // Energy grid for integration (eV)
  currentSpectrum: number[]; // dI/dE spectrum showing where electrons flow (A/eV)
  sdtLeakage: number; // Source-to-drain direct tunneling leakage current (A)
  gateLeakage: number; // Gate oxide tunneling leakage current (A)
  thermionicCurrent: number; // Thermionic current over the barrier (A)
  totalCurrent: number; // Id = SDT + Gate + Thermionic (A)
  ss: number; // Subthreshold swing (mV/dec)
  dibl: number; // DIBL (mV/V)
  quantumShift: number; // Confinement energy shift delta Eq (eV)
}

export interface SweepResultPoint {
  parameterValue: number;
  sdtCurrent: number;
  gateCurrent: number;
  thermionicCurrent: number;
  totalOffCurrent: number;
  totalOnCurrent: number;
  ss: number;
}

export interface OptimizationAdvice {
  analysis: string;
  recommendations: {
    title: string;
    impact: "High" | "Medium" | "Low";
    description: string;
  }[];
  optimalParameters: {
    gateLength: number;
    nanowireDiameter: number;
    oxideThickness: number;
    channelMaterial: string;
  };
  dslOptimized: string;
}
